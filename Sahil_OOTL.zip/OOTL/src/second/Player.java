package second;
import java.util.Random;

public class Player {
	public int Guesses(){
		Random rn = new Random();
		int n1 = rn.nextInt(10);
		return n1;

		
	}

}
