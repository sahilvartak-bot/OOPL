package second;

public class GameLauncher 
{
	public static void main(String args[]) {
		GuessGame g = new GuessGame();
		g.startGame();
	}	

}
