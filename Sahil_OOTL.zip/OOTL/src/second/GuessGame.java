package second;

import java.util.Random;

public class GuessGame 
{
	public void startGame(){
		Player p1 = new Player();
		Player p2 = new Player();
		Player p3 = new Player();
		
		Random rn = new Random();
		int guess = rn.nextInt(10);
		int x = 0;
		
		if(p1.Guesses()==guess) {
			System.out.println("Correct guess by p1");
			x++;
		}
		
		if(p2.Guesses()==guess) {
			System.out.println("Correct guess by p2");
			x++;
		}
		
		if(p3.Guesses()==guess) {
			System.out.println("Correct guess by p3");
			x++;
		}
		
		if(x==0) System.out.println("Guess again");
		
	}

}
