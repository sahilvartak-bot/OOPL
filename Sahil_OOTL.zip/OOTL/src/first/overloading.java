package first;

class overloading {
	public void m1() 
	{
		System.out.println("No argument");
	}
	public void m1(int i) 
	{
		System.out.println("Integer is given "+i );
	}
	public void m1(double d) 
	{
		System.out.println("Integer is given "+ d);
	}
	
	public static void main(String arg[]) 
	{
		overloading o =new overloading();
		o.m1();
		o.m1(5);
		o.m1(2.2);
	}

}

