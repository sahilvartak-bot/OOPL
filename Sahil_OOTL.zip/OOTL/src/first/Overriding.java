package first;

class parent
{
	public void expectations(){
		System.out.println("IIT Engineer");
	}
	
	public void parent_money() 
	{
		System.out.println("Money earned by parent");
	}
}

class student extends parent
{
	public void child_money() 
	{
		System.out.println("Money earned by child");
	}
	
	public void expectations()
	{
		System.out.println("Musician");
	}
}

public class Overriding {
	public static void main(String args[]) 
	{
		parent p = new parent();
		p.expectations();
		p.parent_money();
		
		student s = new student();
		s.expectations();
		s.child_money();
	}
}
