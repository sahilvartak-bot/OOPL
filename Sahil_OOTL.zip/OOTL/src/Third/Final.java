package Third;

public class Final {

	public static void main(String[] args) {
		Quadrilateral quad = new Quadrilateral(1,2,3,4,5,6,7,8);
		
		Trapezoid trap = new Trapezoid(-6.0,0.0,6.0,0.0,-2.0,2.0,2.0,2.0);
		System.out.println("Area of the trapezoid is " + trap.area());
		
		Parallelogram para = new Parallelogram(0.0,0.0,5.0,0.0,3.0,4.0,8.0,4.0);
		System.out.println("Area of the parallelogram is " + para.area());
		
		Rectangle rect = new Rectangle(0.0,0.0,5.0,0.0,0.0,4.0,5.0,4.0);
		System.out.println("Area of the rectangle is " + rect.area());
		
		Square sq = new Square(0.0,0.0,5.0,0.0,0.0,5.0,5.0,5.0);
		System.out.println("Area of the Square is " + sq.area());
		

	}

}
